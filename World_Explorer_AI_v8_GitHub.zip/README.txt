WORLD EXPLORER AI v8

Fișierele care trebuie puse în repository-ul GitHub:
- index.html
- manifest.webmanifest
- sw.js
- icon-192.png
- icon-512.png

În GitHub, intră în repository-ul wold_Explorer_Ai_7 și înlocuiește fișierele vechi cu acestea.
După încărcare, GitHub Pages se actualizează automat.

Funcții incluse:
- căutare oraș
- Wikipedia
- vreme live și prognoză 7 zile
- hartă OpenStreetMap
- servicii și călătorii
- favorite și istoric
- dark mode
- distribuire
- ghid rapid
- instalare PWA
- cache offline pentru fișierele aplicației
