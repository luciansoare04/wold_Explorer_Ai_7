WORLD EXPLORER AI — GENERARE AAB PRIN GITHUB

1. Creează un repository NOU în GitHub, de exemplu: WorldExplorerAI-Android.
2. Încarcă TOATE fișierele și folderele din această arhivă în rădăcina repository-ului:
   app, .github, build.gradle, settings.gradle, gradle.properties și world-explorer-upload.jks.
3. Intră în fila Actions.
4. Deschide „Build Android AAB”.
5. Apasă „Run workflow”.
6. După terminare, deschide rularea și descarcă artifactul „World-Explorer-AI-AAB”.
7. În arhivă vei găsi app-release.aab pentru Google Play Console.

IMPORTANT: păstrează world-explorer-upload.jks și parola. Sunt necesare pentru actualizările aplicației.
