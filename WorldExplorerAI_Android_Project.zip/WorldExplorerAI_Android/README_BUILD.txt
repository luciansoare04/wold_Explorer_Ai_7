WORLD EXPLORER AI - PROIECT ANDROID

Pachet Android: com.luciansoare.worldexplorerai
Versiune: 1.0.0 (versionCode 1)
URL aplicație: https://luciansoare04.github.io/wold_Explorer_Ai_7/

Fișierul de semnare este inclus:
world-explorer-upload.jks
Alias: worldexplorer
Parolă keystore: WorldExplorer2026!
Parolă cheie: WorldExplorer2026!

IMPORTANT: păstrează acest fișier și parolele. Sunt necesare pentru actualizările viitoare.

Pentru compilare în GitHub:
1. Încarcă toate fișierele acestui proiect într-un repository GitHub nou.
2. Intră la Actions.
3. Deschide "Build Android AAB".
4. Apasă "Run workflow".
5. După terminare descarcă artifactul "World-Explorer-AI-AAB".
6. În arhivă se află app-release.aab pentru Google Play Console.
